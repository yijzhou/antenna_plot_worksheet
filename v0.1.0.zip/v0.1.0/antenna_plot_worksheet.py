# antenna plot worksheet
# Yijun Zhou
# yijun.zhou@microsoft.com
# yijun.icloud.com
#
# This software uses Excel as the front end for data input and plot setting 
# and plot the antenna parameters (S11, S21, Efficiency, Pattern) by Python scrips and xlwings
#
# Useage:
# 1) make sure the *.xlsm file and *.py has the same name and put at the same directory
# 2) input S1P, CSV file name and path to the index spreadsheet
# 3) choose the spreadsheet you want to plot and select the data file source form the drop down list
# 4) adjust plot setting (grey area should be not modified)


import numpy as np
import xlwings as xw
import matplotlib.pyplot as plt
import skrf as rf
import csv
#import pandas as pd
#from chart_studio import plotly
#import plotly.offline as pyoff
#import plotly.graph_objs as go


""" def main():
    wb = xw.Book.caller()
    sheet = wb.sheets[0]
    if sheet["A1"].value == "Hello xlwings!":
        sheet["A1"].value = "Bye xlwings!"
    else:
        sheet["A1"].value = "Hello xlwings!" """


@xw.func
def plotS11(file_list, label_list, subplots, title, xlimit, xlabel, ylimit, ylabel, legend_loc, bandmark, caller):
    # plot S11
    # file_list: list of SNP files
    # label_list: list of label text
    # subplots: # of subplots = 1 or 2
    # title: list of titles, title[0]: title for subplot1, title[1]: title for subplot2
    # xlimit: list of xlimits, xlimit[0]: xlimit for subplot1, xlimit[1]: xlimit for subplot2
    # xlabel: list of xlabel, xlabel[0]: xlimit for subplot1, xlabel[1]: xlimit for subplot2
    # ylimit: list of ylimits, ylimit[0]: ylimit for subplot1, ylimit[1]: ylimit for subplot2
    # ylabel: list of ylabel, ylabel[0]: ylimit for subplot1, ylabel[1]: ylimit for subplot2
    # legend_loc: list of legend locations, legend_loc[0] for subplot1, legend_loc[1] for subplot2
    # bandmark: list of bandmark setting (in Option spreadsheet), bandmark[0] for subplot1, bandmark[1] for subplot2
    # caller: reserved parameter, refer the active spreadsheet
    
    subplots = int(subplots)

    fig = plt.figure(figsize=(6*subplots,4))

    for file in file_list:
        
        # # of curves to plot
        n_curve = len(list(filter(None,file_list)))

        if file:
            ntwk = rf.Network(file)
            FreqHz = ntwk.f.tolist()
            FreqMHz = [freq/1e6 for freq in FreqHz]   
            S11_dB = list(ntwk.s11.s_db[:,0,0])

            for i in range(subplots):
                plt.subplot(1,subplots,i+1)

                plt.plot(FreqMHz, S11_dB, label=label_list[file_list.index(file)])

                # plot setting
                plt.title(title[i])
                plt.xlim(float(xlimit[i].split(",")[0]), float(xlimit[i].split(",")[1]))
                plt.ylim(float(ylimit[i].split(",")[0]), float(ylimit[i].split(",")[1]))
                plt.xlabel(xlabel[i])
                plt.ylabel(ylabel[i])
                plt.legend(loc=legend_loc[i])

                # plot bandmark
                bandmark_list = get_bandmark_list(bandmark[i])
                for j in range(int(len(bandmark_list)/2)):
                    plt.axvspan(bandmark_list[2*j], bandmark_list[2*j+1], color='m', alpha=0.1/n_curve, lw=0)

                plt.grid(1)
         
    
    caller.sheet.pictures.add(fig, name='S11', update=True, left=caller.left, top=caller.top)   
    
    return 'Delete the plot and enter the formular to update S11 plot'


@xw.func
def plotVSWR(file_list, label_list, subplots, title, xlimit, xlabel, ylimit, ylabel, legend_loc, bandmark, caller):

    # plot VSWR
    # file_list: list of SNP files
    # label_list: list of label text
    # subplots: # of subplots = 1 or 2
    # title: list of titles, title[0]: title for subplot1, title[1]: title for subplot2
    # xlimit: list of xlimits, xlimit[0]: xlimit for subplot1, xlimit[1]: xlimit for subplot2
    # xlabel: list of xlabel, xlabel[0]: xlimit for subplot1, xlabel[1]: xlimit for subplot2
    # ylimit: list of ylimits, ylimit[0]: ylimit for subplot1, ylimit[1]: ylimit for subplot2
    # ylabel: list of ylabel, ylabel[0]: ylimit for subplot1, ylabel[1]: ylimit for subplot2
    # legend_loc: list of legend locations, legend_loc[0] for subplot1, legend_loc[1] for subplot2
    # bandmark: list of bandmark setting (in Option spreadsheet), bandmark[0] for subplot1, bandmark[1] for subplot2
    # caller: reserved parameter, refer the active spreadsheet

    subplots = int(subplots)

    fig = plt.figure(figsize=(6*subplots,4))

    for file in file_list:
        # # of curves to plot
        n_curve = len(list(filter(None,file_list)))

        if file:
            ntwk = rf.Network(file)
            FreqHz = ntwk.f.tolist()
            FreqMHz = [freq/1e6 for freq in FreqHz]   
            VSWR = list(ntwk.s11.s_vswr[:,0,0])

            for i in range(subplots):
                plt.subplot(1,subplots,i+1)

                # plot setting
                plt.plot(FreqMHz, VSWR, label=label_list[file_list.index(file)])

                plt.title(title[i])
                plt.xlim(float(xlimit[i].split(",")[0]), float(xlimit[i].split(",")[1]))
                plt.ylim(float(ylimit[i].split(",")[0]), float(ylimit[i].split(",")[1]))
                plt.xlabel(xlabel[i])
                plt.ylabel(ylabel[i])
                plt.legend(loc=legend_loc[i])

                # plot bandmark
                bandmark_list = get_bandmark_list(bandmark[i])
                for j in range(int(len(bandmark_list)/2)):
                    plt.axvspan(bandmark_list[2*j], bandmark_list[2*j+1], color='m', alpha=0.1/n_curve, lw=0)

                plt.grid(1)
         
    
    caller.sheet.pictures.add(fig, name='VSWR', update=True, left=caller.left, top=caller.top)   
    
    return 'Delete the plot and enter the formular to update VSWR plot'


@xw.func
def plotS21(file_list, label_list, subplots, title, xlimit, xlabel, ylimit, ylabel, legend_loc, bandmark, caller):
    # plot S21
    # file_list: list of SNP files
    # label_list: list of label text
    # subplots: # of subplots = 1 or 2
    # title: list of titles, title[0]: title for subplot1, title[1]: title for subplot2
    # xlimit: list of xlimits, xlimit[0]: xlimit for subplot1, xlimit[1]: xlimit for subplot2
    # xlabel: list of xlabel, xlabel[0]: xlimit for subplot1, xlabel[1]: xlimit for subplot2
    # ylimit: list of ylimits, ylimit[0]: ylimit for subplot1, ylimit[1]: ylimit for subplot2
    # ylabel: list of ylabel, ylabel[0]: ylimit for subplot1, ylabel[1]: ylimit for subplot2
    # legend_loc: list of legend locations, legend_loc[0] for subplot1, legend_loc[1] for subplot2
    # bandmark: list of bandmark setting (in Option spreadsheet), bandmark[0] for subplot1, bandmark[1] for subplot2
    # caller: reserved parameter, refer the active spreadsheet
    
    subplots = int(subplots)

    fig = plt.figure(figsize=(6*subplots,4))

    for file in file_list:
        
        # # of curves to plot
        n_curve = len(list(filter(None,file_list)))

        if file:
            ntwk = rf.Network(file)
            FreqHz = ntwk.f.tolist()
            FreqMHz = [freq/1e6 for freq in FreqHz]   
            S21_dB = list(ntwk.s21.s_db[:,0,0])

            for i in range(subplots):
                plt.subplot(1,subplots,i+1)

                plt.plot(FreqMHz, S21_dB, label=label_list[file_list.index(file)])

                # plot setting
                plt.title(title[i])
                plt.xlim(float(xlimit[i].split(",")[0]), float(xlimit[i].split(",")[1]))
                plt.ylim(float(ylimit[i].split(",")[0]), float(ylimit[i].split(",")[1]))
                plt.xlabel(xlabel[i])
                plt.ylabel(ylabel[i])
                plt.legend(loc=legend_loc[i])

                # plot bandmark
                bandmark_list = get_bandmark_list(bandmark[i])
                for j in range(int(len(bandmark_list)/2)):
                    plt.axvspan(bandmark_list[2*j], bandmark_list[2*j+1], color='m', alpha=0.1/n_curve, lw=0)

                plt.grid(1)
         
    
    caller.sheet.pictures.add(fig, name='S21', update=True, left=caller.left, top=caller.top)   
    
    return 'Delete the plot and enter the formular to update S21 plot'


@xw.func
def plotEff(file_list, label_list, subplots, title, xlimit, xlabel, ylimit, ylabel, legend_loc, bandmark, caller):
    # plot Efficiency
    # file_list: list of CSV files
    # label_list: list of label text
    # subplots: # of subplots = 1 or 2
    # title: list of titles, title[0]: title for subplot1, title[1]: title for subplot2
    # xlimit: list of xlimits, xlimit[0]: xlimit for subplot1, xlimit[1]: xlimit for subplot2
    # xlabel: list of xlabel, xlabel[0]: xlimit for subplot1, xlabel[1]: xlimit for subplot2
    # ylimit: list of ylimits, ylimit[0]: ylimit for subplot1, ylimit[1]: ylimit for subplot2
    # ylabel: list of ylabel, ylabel[0]: ylimit for subplot1, ylabel[1]: ylimit for subplot2
    # legend_loc: list of legend locations, legend_loc[0] for subplot1, legend_loc[1] for subplot2
    # bandmark: list of bandmark setting (in Option spreadsheet), bandmark[0] for subplot1, bandmark[1] for subplot2
    # caller: reserved parameter, refer the active spreadsheet
    
    subplots = int(subplots)

    fig = plt.figure(figsize=(6*subplots,4))
    
    for file in file_list:
        
        # # of curves to plot
        n_curve = len(list(filter(None,file_list)))
        
        if file:

            FreqMHz, Efficiency = chamber_csv(file)

            for i in range(subplots):
                plt.subplot(1,subplots,i+1)
                plt.plot(FreqMHz, Efficiency, label=label_list[file_list.index(file)])
                
                # plot setting
                plt.title(title[i])
                plt.xlim(float(xlimit[i].split(",")[0]), float(xlimit[i].split(",")[1]))
                plt.ylim(float(ylimit[i].split(",")[0]), float(ylimit[i].split(",")[1]))
                plt.xlabel(xlabel[i])
                plt.ylabel(ylabel[i])
                plt.legend(loc=legend_loc[i])

                # plot bandmark
                bandmark_list = get_bandmark_list(bandmark[i])
                for j in range(int(len(bandmark_list)/2)):
                    plt.axvspan(bandmark_list[2*j], bandmark_list[2*j+1], color='m', alpha=0.1/n_curve, lw=0)

                plt.grid(1)

    caller.sheet.pictures.add(fig, name='Efficiency', update=True, left=caller.left, top=caller.top)   
    
    return 'Delete the plot and enter the formular to update Efficiency plot'


@xw.func
def plotPattern_3D_Heatmap(file, freq, pscale, caller):
    # function to plot antenna pattern (3D heatmap)
    # file: CSV file for chamber measurement
    # freq: frequency to plot (MHz)
    # pscale: scale of the plot, seperated by comma
    # caller: reserved parameter, refer the active spreadsheet

    # Read antenna pattern data:
    Prad, row_angle, column_angle, primiary_sweep = antenna_pattern(file, freq)

    XX = np.array(row_angle)
    YY = np.array(column_angle)

    Prad = np.array(Prad)
    Prad = np.transpose(Prad)

    Prad_min = float(pscale.split(",")[0])
    Prad_max = float(pscale.split(",")[1])
    
    fig, ax = plt.subplots()
    
    c = ax.pcolormesh(XX, YY, Prad, cmap='rainbow', vmin=Prad_min, vmax=Prad_max)
    
    # set the limits of the plot to the limits of the data
    ax.axis([XX.min(), XX.max(), YY.min(), YY.max()])

    fig.colorbar(c, ax=ax)

    if primiary_sweep == 'phi':

        plt.xlabel('Phi')
        plt.ylabel('Theta')

    else:
        plt.xlabel('Theta')
        plt.ylabel('Phi')

    plt.title('Antenna power (dBm)')

    caller.sheet.pictures.add(fig, name='3D Pattern_heatmap', update=True, left=caller.left, top=caller.top) 
    
    return 'Delete the plot and enter the formular to update Pattern plot'

    
""" @xw.func
def plotPattern_3D_polar(file, freq, pscale, caller):
    # function to plot antenna pattern (3D polar)

    gain, theta, phi = antenna_pattern(file, freq)

    gain = np.array(gain)

    gain_min = float(pscale.split(",")[0])
    gain_max = float(pscale.split(",")[1])
    

    fig = plt.figure()
    ax = fig.add_subplot(111, projection='3d')

    phiSize = gain.shape[0]                                                                                   # Finds the phi & theta range
    thetaSize = gain.shape[1]

    phi_step= phi[1]-phi[0]
    theta_step = theta[1]-theta[0]

    X = np.ones((phiSize, thetaSize))                                                                           # Prepare arrays to hold the cartesian coordinate data.
    Y = np.ones((phiSize, thetaSize))
    Z = np.ones((phiSize, thetaSize))

    for pp in range(phiSize):                                                                                  # Iterate over all phi/theta range
        for tt in range(thetaSize):
            e = gain[pp][tt]

            xe, ye, ze = sph2cart1(e, tt*theta_step/180*np.pi, pp*phi_step/180*np.pi)                                   # Calculate cartesian coordinates

            X[pp, tt] = xe                                                                                  # Store cartesian coordinates
            Y[pp, tt] = ye
            Z[pp, tt] = ze

    c = ax.plot_surface(X, Y, Z, cmap='rainbow', vmin=gain_min, vmax=gain_max)   

    fig.colorbar(c, ax=ax)

    plt.title('Antenna gain (dB)')

    caller.sheet.pictures.add(fig, name='3D Pattern_polar', update=True, left=caller.left, top=caller.top) 
    
    return 'Delete the plot and enter the formular to update Pattern plot' """

""" @xw.func
def plotPattern_3D_polar2(file, freq, pscale, caller):
    # function to plot antenna pattern (3D polar interactive)

    gain, theta, phi = antenna_pattern(file, freq)

    theta = np.array(theta)/180*np.pi
    phi = np.array(phi)/180.*np.pi

    gain = np.array(gain)
    gain = np.transpose(gain)

    gain_min = float(pscale.split(",")[0])
    gain_max = float(pscale.split(",")[1])
    
    # Dipole pattern for validation 
    for t in range(len(theta)):
        for p in range(len(phi)):
            gain[t][p] = 5*np.sin(theta[t])

    
    pGrid, tGrid = np.meshgrid(phi, theta)

    x = gain * np.cos(pGrid) * np.sin(tGrid)  # x = r*cos(phi)*sin(theta)
    y = gain * np.sin(pGrid) * np.sin(tGrid)  # y = r*sin(phi)*sin(theta)
    z = gain * np.cos(tGrid)                  # z = r*cos(theta)

    surface = go.Surface(x=x, y=y, z=z, colorscale='rainbow', cmin=gain_min, cmax=gain_max)
    
    data = [surface]

    layout = go.Layout(
    title='Antenna gain (dB)',
    scene=dict(
        xaxis=dict(
            gridcolor='rgb(255, 255, 255)',
            zerolinecolor='rgb(255, 255, 255)',
            showbackground=True,
            backgroundcolor='rgb(230, 230,230)'
        ),
        yaxis=dict(
            gridcolor='rgb(255, 255, 255)',
            zerolinecolor='rgb(255, 255, 255)',
            showbackground=True,
            backgroundcolor='rgb(230, 230,230)'
        ),
        zaxis=dict(
            gridcolor='rgb(255, 255, 255)',
            zerolinecolor='rgb(255, 255, 255)',
            showbackground=True,
            backgroundcolor='rgb(230, 230,230)'
            )
        )
    )

    fig = go.Figure(data=data, layout=layout)
    pyoff.plot(fig, filename='antenna-pattern-3D-polar.html')

    caller.sheet.pictures.add(fig, name='antenna-pattern-3D-polar', update=True, left=caller.left, top=caller.top) 
    
    return 'Delete the plot and enter the formular to update Pattern plot' """

@xw.func
def plotPattern_2D_polar(file, freq, pscale, caller):
    # function to plot antenna pattern (2D polar) for XY, XZ, YZ planes
    # file: CSV file for chamber measurement
    # freq: frequency to plot (MHz)
    # pscale: scale of the plot, seperated by comma
    # caller: reserved parameter, refer the active spreadsheet

    # Read antenna pattern data:
    Prad, row_angle, column_angle, primiary_sweep = antenna_pattern(file, freq)
    
    Prad = np.array(Prad)

    Prad_min = float(pscale.split(",")[0])
    Prad_max = float(pscale.split(",")[1])

    if primiary_sweep == 'phi':

        theta = column_angle        # [0~180]
        phi = row_angle             # [0~360]

        theta_full = theta + [360-a for a in list(reversed(theta))[1:]]         # [0~360]
        theta_full = np.array(theta_full)/180*np.pi
        phi_full = np.array(phi)/180*np.pi

        # XY plane, find Prad data for theta = 90deg
        theta90 = theta.index(90)
        Prad_phi_XY = Prad[:, theta90]

        # XZ plane, find Prad data for phi = 0deg
        phi0 = phi.index(0)
        phi180 = phi.index(180)
        Prad_theta_0 = Prad[phi0]
        Prad_theta_180 = Prad[phi180]
        Prad_theta_XZ =np.concatenate((Prad_theta_0, np.flip(Prad_theta_180)[1:]))

        # YZ plane, find Prad data for phi = 90deg
        phi90 = phi.index(90)
        phi270 = phi.index(270)
        Prad_theta_90 = Prad[phi90]
        Prad_theta_270 = Prad[phi270]
        Prad_theta_YZ =np.concatenate((Prad_theta_90, np.flip(Prad_theta_270)[1:]))

    if primiary_sweep == 'theta':

        theta = row_angle           # [-180~180]
        phi = column_angle          # [0~180]

        theta_full = np.array(theta)/180*np.pi
        phi_full = phi + [360-a for a in list(reversed(phi))[1:]]       # [0~360]
        phi_full = np.array(phi_full)/180*np.pi

        # XY plane, find Prad data for theta = 90deg
        theta90 = theta.index(90)
        Prad_phi_90 = Prad[theta90]
        theta_neg90 = theta.index(-90)
        Prad_phi_neg90 = Prad[theta_neg90]
        Prad_phi_XY = np.concatenate((Prad_phi_90, Prad_phi_neg90[1:]))

        # XZ plane, find Prad data for phi = 0deg
        phi0 = phi.index(0)
        Prad_theta_XZ = Prad[:, phi0]

        # XZ plane, find Prad data for phi = 0deg
        phi90 = phi.index(90)
        Prad_theta_YZ = Prad[:, phi90]


    fig = plt.figure(figsize=(6*3,4))

    #plt.subplot(1,3,1, projection='polar')           
    #plt.polar(phi_full, Prad_phi_XY,'b')
    ax1 = fig.add_subplot(131,polar=True)
    ax1.plot(phi_full, Prad_phi_XY)
    ax1.set_rmax(Prad_max)
    ax1.set_rmin(Prad_min)
    ax1.title.set_text('XY plane, theta=90deg')
    ax1.set_theta_zero_location("N")

    #plt.subplot(1,3,2, projection='polar')           
    #plt.polar(theta_full, Prad_theta_XZ,'b')
    ax2 = fig.add_subplot(132,polar=True)
    ax2.plot(theta_full, Prad_theta_XZ)
    ax2.set_rmax(Prad_max)
    ax2.set_rmin(Prad_min)
    ax2.title.set_text('XZ plane, phi=0deg')
    ax2.set_theta_zero_location("N")

    #plt.subplot(1,3,3, projection='polar')         
    #plt.polar(theta_full, Prad_theta_YZ,'b')
    ax3 = fig.add_subplot(133,polar=True)
    ax3.plot(theta_full, Prad_theta_YZ)
    ax3.set_rmax(Prad_max)
    ax3.set_rmin(Prad_min)
    ax3.title.set_text('YZ plane, phi=90deg')
    ax3.set_theta_zero_location("N")

    caller.sheet.pictures.add(fig, name='2D Pattern_polar', update=True, left=caller.left, top=caller.top) 
    
    return 'Delete the plot and enter the formular to update Pattern plot'


def is_number(s):
    try:
        float(s)
        return True
    except ValueError:
        return False

def sph2cart1(r, th, phi):
  x = r * np.cos(phi) * np.sin(th)
  y = r * np.sin(phi) * np.sin(th)
  z = r * np.cos(th)

  return x, y, z

def get_bandmark_list(bandmark):
    # find bandmark list [freq1,freq2,freq3,freq4,...] from "Options" sheet

    # get active workbook
    wb = xw.books.active

    # get the spreadsheet by the name "Options"
    sht = wb.sheets['Options']

    # get first column

    first_column = sht.range('A1:A500').value

    # search "#Bandmark"
    rr = first_column.index('#Bandmark')
    
    # get bandmark row
    bandmark_row = sht.range((rr+2,2),(rr+2,21)).value

    # search "bandmark"
    cc = bandmark_row.index(bandmark)

    # get full bandmark list (10 bands, 20 frequencies)
    bandmark_list = sht.range((rr+3,cc+2),(rr+22,cc+2)).value

    # trim None from the list
    bandmark_list = list(filter(None,bandmark_list))

    return bandmark_list

def string_to_array(string):
    # function to change from ['500',...,'6000'] to [500,...,6000]
    string = [ss for ss in string if ss != ""]  # remove empty cell in the last
    return [float(ff) for ff in string]

def chamber_csv(inFile):
    # function to read CSV from chamber
    # return FreqMHz: frequency list; Efficiency: efficinecy list
    with open(inFile, 'r') as file:
        reader = csv.reader(file)     
        for row in reader:
            if row[0] == "Total" and row[1] == "Frequency  (MHz)" and row[2] != "":
                FreqMHz = string_to_array(row[2:])
                
            if row[0] == "" and row[1] == "Efficiency (dB)":
                Efficiency = string_to_array(row[2:])
                break
                
    return FreqMHz, Efficiency

def antenna_pattern(csvfile, freq):
    # function to get antenna pattern of the CSV file:
    # return antenna_power: 2D list for the radaiated power [row x column]
    # if primiary_sweep = phi (0~360), antenna_power is [phi x theta], antenna_power[0] is a theta sweep (0~180)
    # if primiary_sweep = theta (-180~180), antenna_power is [theta x phi], antnena_power[0] is a phi sweep (0~180)

    antenna_power = []
    row_angle = []
    column_angle = []
    

    FoundTotal = 0
    FoundFreq = 0

    with open(csvfile, 'r') as file:
        reader = csv.reader(file)     
        for row in reader:
            if FoundTotal == 0:
                if row[0] == "Total" and row[1] == "Frequency  (MHz)" and row[2] == "":
                    #print ("Found Total")
                    FoundTotal = 1            
            
            else:
                if FoundFreq == 0:
                    if row[0] == "Total" and row[1] == "Frequency  (MHz)" and row[2] != "":
                        #print("Freq not found ...")
                        return []

                    if row[1]:
                        if float(row[1]) == freq:
                            #print ("Found Freq")
                            FoundFreq = 1

                            if "Theta" in row[2]:
                                primary_sweep = "phi"
                            if "Phi" in row[2]:
                                primary_sweep = "theta"

                            column_angle = string_to_array(row[3:])

                else:
                    if row[2]:
                        if is_number((row[2])):
                            row_angle.append(float(row[2]))
                            antenna_power.append(string_to_array(row[3:]))
                            
                    else:
                        break

    return antenna_power, row_angle, column_angle, primary_sweep

#if __name__ == "__main__":
#    xw.Book("antenna_plot_worksheet.xlsm").set_mock_caller()
#    main()

if __name__ == "__main__":
    # To run this with the debug server, set UDF_DEBUG_SERVER = True in the xlwings VBA module
    xw.serve()